var group__core =
[
    [ "AUDIO_INPUT_PIN", "group__core.html#gad6f503b77ed0c93394363460509f5cbd", null ],
    [ "AUDIO_MODE", "group__core.html#ga9c4a39187db1d0a1ad0fa6981920f383", null ],
    [ "AUDIO_RATE", "group__core.html#ga5b972bafb3267e820993812beca1b298", null ],
    [ "EXTERNAL_AUDIO_OUTPUT", "group__core.html#gafed43d5318cc354fe1ab9ede77da8e94", null ],
    [ "STANDARD", "group__core.html#ga0b8ca8ad62b88c01b639bad62eafcbf1", null ],
    [ "STANDARD_PWM_RESOLUTION", "group__core.html#ga800c094e0a14fc31d87a360b3807a1b8", null ],
    [ "STANDARD_PWM_RESOLUTION", "group__core.html#ga800c094e0a14fc31d87a360b3807a1b8", null ],
    [ "STEREO_HACK", "group__core.html#ga41e77c76435031bd6088de496aa2a9e0", null ],
    [ "audioHook", "group__core.html#ga2fca37b988ab369e2f3c3108c683e59d", null ],
    [ "audioTicks", "group__core.html#ga55fa9d48f327b646c2f71cef7da7b8f0", null ],
    [ "mozziMicros", "group__core.html#gaaa6a42d80c5297407a45ca8bf3c1c7fe", null ],
    [ "pauseMozzi", "group__core.html#ga0dc2dc3b2c20b081df4d55ad039f64e5", null ],
    [ "startMozzi", "group__core.html#ga75aa9f4a501f4b167343b8caac8c6837", null ],
    [ "stopMozzi", "group__core.html#ga8d9307490ec05ad28539d513c73a5c20", null ],
    [ "unPauseMozzi", "group__core.html#ga1718c5f0bbb56cc4b2db55702750f43f", null ],
    [ "updateAudio", "group__core.html#ga41f0db3f560ff1fdec78f9c60822466e", null ],
    [ "updateControl", "group__core.html#ga59d187b915b2e366c88489e52801951a", null ]
];